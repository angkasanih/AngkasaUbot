import os
from dotenv import load_dotenv

load_dotenv(".env")

MAX_BOT = int(os.getenv("MAX_BOT", "200"))

DEVS = list(map(int, os.getenv("DEVS", "6736986837").split()))

API_ID = int(os.getenv("API_ID", "20605735"))

API_HASH = os.getenv("API_HASH", "5bcd7f6a093c804d38263259381a4ef0")

BOT_TOKEN = os.getenv("BOT_TOKEN", "8688103117:AAFO7dgxAoMOulJqD4KTKfD29zEXoXVuW0o")

OWNER_ID = int(os.getenv("OWNER_ID", "6736986837"))

BLACKLIST_CHAT = list(map(int, os.getenv("BLACKLIST_CHAT", "-1002312835928").split()))

RMBG_API = os.getenv("RMBG_API", "a6qxsmMJ3CsNo7HyxuKGsP1o")

MONGO_URL = os.getenv("MONGO_URL", "mongodb+srv://alldatabaseangkasa_db_user:84lRVzUFfMnhZrIf@angkasanih.fsdllhf.mongodb.net/?appName=angkasanih")

LOGS_MAKER_UBOT = int(os.getenv("LOGS_MAKER_UBOT", "-1003282036854"))
